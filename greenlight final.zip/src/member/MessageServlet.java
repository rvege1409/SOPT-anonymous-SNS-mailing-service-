package member;
import java.io.IOException;
import java.util.*;

import javax.servlet.http.*;
import javax.servlet.*;

import java.io.*;
import java.sql.Connection;
import java.sql.SQLException;

import member.MemberDTO;
import member.DBConnection;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

public class MessageServlet extends HttpServlet{
	 public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
		 doPost(request,response);
	 }
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
      
      request.setCharacterEncoding("UTF-8");
      Connection conn = DBConnection.getConnection();
      MemberDAO dao = new MemberDAO(conn);
      System.out.println("servlet connect");
      HttpSession session = request.getSession();
      
      MemberDTO dto = (MemberDTO)session.getAttribute("login_session");
      String sid = dto.getID();
      HttpSession session1 = request.getSession();
      String rid = (String)session1.getAttribute("rID");
      String content = request.getParameter("content");
      System.out.println(sid);
      System.out.println(rid);
      System.out.println(content);
      try {
		dao.sendMessage(rid, sid, content);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
     
      response.sendRedirect("Mypage.jsp");
   }
}