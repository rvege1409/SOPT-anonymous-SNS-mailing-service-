package member;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Enumeration;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import com.mysql.jdbc.interceptors.SessionAssociationInterceptor;

/**
 * Servlet implementation class BtnLight
 */
@WebServlet("/BtnLight")
public class BtnLight extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection con = null;
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession();
		java.sql.Statement stmt = null;
		PreparedStatement pstmt=null;
		 MemberDTO dto = (MemberDTO)session.getAttribute("login_session");	 
		 String sql;
		 ResultSet rs = null;
		 
  		   String url = null;
  		   String nowID;
  		   String targetID;
  		 
  		 
  		   nowID = (String) session.getAttribute("nowID");
  		   targetID = (String) session.getAttribute("targetID");

  		   
  		 System.out.println(" 0 0 0 0 0 0 0 0");
  		 
  		 try {
  		      
  	    	
  	    	 sql = "UPDATE member SET `ssome` = + '"+nowID+"' +  where `ID` =+'"+targetID+"'";
  	    	 
  	    	System.out.println(" 9 9 9 9 9 9 9 "); 
  	    	pstmt = con.prepareStatement(sql);	
  	    	System.out.println(" 1 1 1 1 1 1 1");
  	    	
//  	    	pstmt.setString(1, nowID);
  	    	System.out.println(" 2 2 2 2 2 2 2");
  	    	pstmt.executeUpdate();
  	    	System.out.println(" 3 3 3 3 3 3 3 3 ");
  	       pstmt.close();
  	       
  	     } catch (Exception e) {
  	       System.out.println(e.toString());
  	     }
  		   
  		   
  		/*   
  	 try {
         con = (Connection) DBConnection.getConnection();
         stmt = con.createStatement();
          sql = "select `ID`, `PW`, `live`, `character`, `hobby`, `reli`, `name`, `classof`,`age`,`gender` from member where ID=+'"+nowID+"'"; 
         rs = stmt.executeQuery(sql);
         System.out.println(" 2 2 2 2 2 2 2 ");
         String db_id = null;
         String db_pw = null;
          String db_live =null;
          String db_character =null;
          String db_hobby =null;
          String db_reli =null;
          String db_name =null;
          String db_classof =null;
          String db_age =null;
          String db_gender =null;

         
         
         while(rs.next()) {
            db_id = rs.getString("ID");
            db_pw = rs.getString("PW");
             db_live =rs.getString("live");
             db_character =rs.getString("character");
             db_hobby =rs.getString("hobby");
             db_reli =rs.getString("reli");
             db_name =rs.getString("name");
             db_classof =rs.getString("classof");
             db_age =rs.getString("age");
             db_gender = rs.getString("gender");
         }
         
         System.out.println("id : " + db_id);
         System.out.println("id : " + db_live);
         System.out.println("id : " + db_age);
         
         
         
  	     }
  	 catch (Exception e) {
  	       System.out.println(e.toString());
  	     }
  	 finally {
        if(rs!=null){
            try {
                rs.close();
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        if (stmt != null) {
            try {
                stmt.close();
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        if (con != null) {
            try {
                con.close();
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
  	 }
  	 */
  		
  		 
  		 /*
  		    sql = "UPDATE member SET `ssome`=nowID  where ID =+'"+targetID+"'";
  		   
  		 try {
  			 con = (Connection) DBConnection.getConnection();
  			 stmt = (Statement) con.createStatement();
//  			 stmt.executeQuery(sql);
  			 stmt.executeUpdate(sql);
	    	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
  		   */
  		 
  		   
  		   
    url = "http://localhost:8080/tmp_light/view.jsp?id=" + targetID;
    response.sendRedirect(url);
	
	}

}
