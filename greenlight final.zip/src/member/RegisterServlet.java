package member;
import java.io.IOException;
import java.util.*;
import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
import java.sql.Connection;


public class RegisterServlet extends HttpServlet{
   public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
      request.setCharacterEncoding("euc-kr");
      Connection conn = DBConnection.getConnection();
      MemberDAO dao = new MemberDAO(conn);
      
      
      String ID = request.getParameter("ID");
      String password = request.getParameter("PASSWORD");
      String live = request.getParameter("LIVE");
      String character = request.getParameter("CHARACTER");
      String hobby = request.getParameter("HOBBY");
      String reli = request.getParameter("RELI");
      String name = request.getParameter("NAME");
      String classof = request.getParameter("CLASSOF");
      String age = request.getParameter("AGE");
      String introduce = request.getParameter("INTRODUCE");
      String gender = request.getParameter("GENDER");


      
      MemberDTO dto = new MemberDTO();
      dto.setID(ID);
      dto.setPW(password);
      dto.setlive(live);
      dto.setCharacter(character);
      dto.sethobby(hobby);
      dto.setreli(reli);
      dto.setName(name);
      dto.setClassof(classof);
      dto.setAge(age);
      dto.setintroduce(introduce);
      dto.setgender(gender);
      
      
      dao.insertData(dto);
      //response.setCharacterEncoding("text/html;charset=euc-kr");
      PrintWriter out = response.getWriter();
      out.println("<script>");
      out.println("alert('SUCCESS');");
      out.println("location.href='login.html'");
      out.println("</script>");
      out.close();
      //response.sendRedirect("index.html");
   }
}