package member;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.sql.Date;
import java.util.*;
import java.text.*; 
import javax.servlet.http.HttpServletResponse;
 
public class MemberDAO {
 
   //������ -> ����Ŭ �����ͺ��̽� ���� ��ü ����
   private Connection conn = null;
   public MemberDAO(Connection conn) {
     this.conn = conn;		 
   }
 
   public MemberDAO() {}
   //�Է� �޼ҵ�
   public void insertData(MemberDTO dto) {
     
     PreparedStatement pstmt = null;
     int result = 0;
     try {
       //hitcount�� 0, created�� SYSDATE�� �Է�.
      
        

       String sql = "insert into member (`ID`,`PW`, `live`, `character`,`hobby`,`reli`,`name`,`classof`,`age`,`fileurl`, `introduce`, `gender`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)"; 
       

       pstmt = conn.prepareStatement(sql);   
       pstmt.setString(1, dto.getID());
       pstmt.setString(2, dto.getPW());
       pstmt.setString(3, dto.getlive());
       pstmt.setString(4, dto.getCharacter());
       pstmt.setString(5, dto.gethobby());
       pstmt.setString(6, dto.getreli());
       pstmt.setString(7, dto.getName());
       pstmt.setString(8, dto.getClassof());
       pstmt.setString(9, dto.getAge());
       pstmt.setString(10, dto.getPhoto());
       pstmt.setString(11, dto.getintroduce());
       pstmt.setString(12, dto.getgender());
       System.out.println("111");
       pstmt.executeUpdate();
        System.out.println("111");
      //   stmt = conn.prepareStatement(sql);
      // pstmt.setString(1, dto.getName());  
       //pstmt.setString(2, dto.getClassof());  //userPwd
       //pstmt.setString(3, dto.getAge());  //userName
      // stmt.setString(1, dto.getCharacter());  //birth
      // stmt.setString(2, dto.getlive());  //tel
       //stmt.setString(3, dto.gethobby());
       //pstmt.setString(7, dto.getreli());
       
       
       
       //stmt.executeUpdate(sql);
       System.out.println("111");

      // System.out.println(result);   
       pstmt.close();
       
     } catch (Exception e) {
       System.out.println(e.toString());
     }
     //return result;
   }
   
   //��ü �ڷ� �б� �޼ҵ�(�����ε�)
   
   
 //���� �޼ҵ�
   public int deleteData(String userId){
       int result = 0;
       
       PreparedStatement pstmt = null;
       String sql;
       
       try {
           
           sql="DELETE from member where `ID`='"+userId+"'";
           
           pstmt = conn.prepareStatement(sql);
          
           result=pstmt.executeUpdate();
           
       } catch (Exception e) {
           System.out.println(e.toString());
       }

       return result;
   }
   /*
   //�����ڿ� ���� �޼ҵ�(�����ε�)
   public int deleteData(String userId) {
     int result = 0;
     PreparedStatement pstmt = null;
     String sql;
     try {
       sql = "DELETE FROM member WHERE userId=?";
       pstmt = conn.prepareStatement(sql);
       pstmt.setString(1, userId);  //userId
       result = pstmt.executeUpdate();
       pstmt.close();
     } catch (Exception e) {
        System.out.println(e.toString());
     }
     return result;
   }
   
   //Ư�� ȸ�� �б� �޼ҵ�
   public MemberDTO getReadData(String id, String pw) {
     MemberDTO dto = null;
     PreparedStatement pstmt = null;
     ResultSet rs = null;
     String sql = "";
     try {
      sql = "SELECT userId, userName, TO_CHAR(birth, 'YYYY-MM-DD') as birth, tel, TO_CHAR(created, 'YYYY-MM-DD') as created";
       sql += " FROM member WHERE userId=? AND userPwd=?";
       pstmt = conn.prepareStatement(sql);
       pstmt.setString(1, id);
       pstmt.setString(2, pw);
       rs = pstmt.executeQuery();
       if (rs.next()) {
         dto = new MemberDTO();
         dto.setUserId(rs.getString(1));  //userId
         dto.setUserName(rs.getString(2));  //userName
         dto.setBirth(rs.getString(3));  //birth
         dto.setTel(rs.getString(4));  //tel
         dto.setCreated(rs.getString(5));  //created
       }
       rs.close();
       pstmt.close();
     } catch (Exception e) {
       System.out.println(e.toString());
     }
     return dto;
   }
   
   //Ư�� ȸ�� �б� �޼ҵ� (�������̵�)
   public MemberDTO getReadData(String id) {
     MemberDTO dto = null;
     PreparedStatement pstmt = null;
     ResultSet rs = null;
     String sql = "";
     try {
       sql = "SELECT userId, userName, TO_CHAR(birth, 'YYYY-MM-DD') as birth, tel, TO_CHAR(created, 'YYYY-MM-DD') as created";
       sql += " FROM member WHERE userId=?";
      pstmt = conn.prepareStatement(sql);
       pstmt.setString(1, id);
       rs = pstmt.executeQuery();
       if (rs.next()) {
         dto = new MemberDTO();
         dto.setUserId(rs.getString(1));  //userId
         dto.setUserName(rs.getString(2));  //userName
         dto.setBirth(rs.getString(3));  //birth
         dto.setTel(rs.getString(4));  //tel
         dto.setCreated(rs.getString(5));  //created
       }
       rs.close();
       pstmt.close();
     } catch (Exception e) {
       System.out.println(e.toString());
     }
     return dto;
   }
   */
 public void updateData(MemberDTO dto, String ID) {
       PreparedStatement pstmt = null;
        String sql;
        try {
          
          sql = "UPDATE member SET `ID`=?,`PW`=?, `live`=?, `character`=?,`hobby`=?,`reli`=?,`name`=?,`classof`=?,`age`=?,`gender`=?,`introduce`=? where `ID`=+'"+ID+"'";
     
       pstmt = conn.prepareStatement(sql);
       
         pstmt.setString(1, dto.getID());
         pstmt.setString(2, dto.getPW());
         pstmt.setString(3, dto.getlive());
         pstmt.setString(4, dto.getCharacter());
         pstmt.setString(5, dto.gethobby());
         pstmt.setString(6, dto.getreli());
         pstmt.setString(7, dto.getName());
         pstmt.setString(8, dto.getClassof());
         pstmt.setString(9, dto.getAge());
         pstmt.setString(10, dto.getgender());
         pstmt.setString(11, dto.getintroduce());
         
       pstmt.executeUpdate();
       pstmt.close();
       }
         catch (Exception e) {
          System.out.println(e.toString());
        }
      }
 
 public void sendMessage(String rID, String sID, String content) throws SQLException, IOException {
	

	 java.sql.Statement stmt = null;
    
     Connection con = null;
     con = DBConnection.getConnection();

     String sql;
      String sql1;
      String sql2;
      ResultSet rs1 =null;
      ResultSet rs2 =null;									
      sql1 = "select `num` from ssome where `greenSend` ='"+rID+"'and `greenReceive`= '"+sID+"'";
      sql2 = "select `num` from ssome where `greenSend` ='"+sID+"'and `greenReceive`='"+rID+"'";
      stmt = con.createStatement();
      rs1 = stmt.executeQuery(sql1);
      rs2 = stmt.executeQuery(sql2);
      if(rs1 != null && rs2 !=null){
      try {
    	PreparedStatement pstmt = null;
        sql = "insert into messagebox (`recipient`,`sender`, `content`, `date`) VALUES (?,?,?,?)"; 
        pstmt = conn.prepareStatement(sql);
        java.text.SimpleDateFormat formatter = new java.text.SimpleDateFormat("yyyyMMddHHmmss");
        String today = formatter.format(new java.util.Date());
     
       pstmt.setString(1, rID);
       pstmt.setString(2, sID);
       pstmt.setString(3, content);
       pstmt.setString(4, today);
     pstmt.executeUpdate();
     pstmt.close();
     }
       catch (Exception e) {
        System.out.println(e.toString());
      }
     }
      else{
    	System.out.println("������ ���� �� �����ϴ�.");
      }
    }
 
 public void updatePhoto(String photo, String ID) {
       PreparedStatement pstmt = null;
        String sql;
        try {
          
          sql = "UPDATE member SET `fileurl`=? where `ID`=+'"+ID+"'";
     
       pstmt = conn.prepareStatement(sql);
       
       pstmt.setString(1, photo);
       
       pstmt.executeUpdate();
       pstmt.close();
       }
         catch (Exception e) {
          System.out.println(e.toString());
        }
      }
   
 public ArrayList<MemberDTO> getListsData(String name, String gender) {
	     ArrayList<MemberDTO> lists = new ArrayList<MemberDTO>();
	     PreparedStatement pstmt = null;
	     ResultSet rs = null;
	     String sql;
	     
	     System.out.println("4");
	     System.out.println(gender);
	     System.out.println(name);
	     //��ü �����͸� �о���� ������ �ۼ���.
	     
	     try {
	       sql ="select * from member where gender ='"+gender+"'and name='"+name+"'";
		   pstmt = conn.prepareStatement(sql);
	       System.out.println(sql);
		   System.out.println("kkk");
	       System.out.println("5.5");
	       System.out.println("5.6");
	       rs = pstmt.executeQuery(sql);
	       System.out.println("6");
	       //�����ͺ��̽����� �о�� �����Ͱ� �������� ���
	       //�ݺ������� ó�� 
	       while (rs.next()) {
	         //������ �׸��� �������� ���
	         //MemberDTO ��ü�� �����ؼ� ����
	         MemberDTO dto = new MemberDTO();
	         dto.setID(rs.getString(2));
	         dto.setPW(rs.getString(3));
	         dto.setlive(rs.getString(4));
	         dto.setCharacter(rs.getString(5));
	         dto.sethobby(rs.getString(6));
	         dto.setreli(rs.getString(7));
	         dto.setName(rs.getString(8));
	         dto.setClassof(rs.getString(9));
	         dto.setAge(rs.getString(10));
	         dto.setPhoto(rs.getString(11));
	         dto.setgender(rs.getString(13));
	         dto.setintroduce(rs.getString(14));
	         
	         //�����ͺ��̽����� �о�� �����Ͱ� �������� ���
	         //�÷��ǿ� �߰�
	         lists.add(dto);
	       }
	       rs.close();
	       pstmt.close();
	       System.out.println("7");
	     } catch (Exception e) {
	       System.out.println(e.toString());
	       System.out.println("8");

	     }
	     return lists;
	   }


public ArrayList<MemberDTO> getListsData(String ID) {
    ArrayList<MemberDTO> lists = new ArrayList<MemberDTO>();
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    String sql;
    
    System.out.println("4");
   
    //��ü �����͸� �о���� ������ �ۼ���.
    
    try {
      sql ="select * from member where ssome ='"+ID+"'";
	   pstmt = conn.prepareStatement(sql);
     
      rs = pstmt.executeQuery(sql);
     
      //�����ͺ��̽����� �о�� �����Ͱ� �������� ���
      //�ݺ������� ó�� 
      while (rs.next()) {
        //������ �׸��� �������� ���
        //MemberDTO ��ü�� �����ؼ� ����
        MemberDTO dto = new MemberDTO();
        dto.setID(rs.getString(2));
        dto.setPW(rs.getString(3));
        dto.setlive(rs.getString(4));
        dto.setCharacter(rs.getString(5));
        dto.sethobby(rs.getString(6));
        dto.setreli(rs.getString(7));
        dto.setName(rs.getString(8));
        dto.setClassof(rs.getString(9));
        dto.setAge(rs.getString(10));
        dto.setPhoto(rs.getString(11));
        dto.setgender(rs.getString(13));
        dto.setintroduce(rs.getString(14));
        
        //�����ͺ��̽����� �о�� �����Ͱ� �������� ���
        //�÷��ǿ� �߰�
        lists.add(dto);
      }
      rs.close();
      pstmt.close();
      
    } catch (Exception e) {
      System.out.println(e.toString());

    }
    return lists;
  }

}
   /*
   //���� �޼ҵ�
   public int updateData(MemberDTO dto) {
     int result = 0;
     PreparedStatement pstmt = null;
     String sql;
     try {
       sql = "UPDATE member SET userName=?, birth=?, tel=?";
       sql += " WHERE userId=? AND userPwd=?";
       pstmt = conn.prepareStatement(sql);
       pstmt.setString(1, dto.getUserName());  //userName
       pstmt.setString(2, dto.getBirth());  //userBirth
       pstmt.setString(3, dto.getTel());  //userTel
       pstmt.setString(4, dto.getUserId());  //userId
       pstmt.setString(5, dto.getUserPwd());  //userPwd
       result = pstmt.executeUpdate();
       pstmt.close();
     } catch (Exception e) {
       System.out.println(e.toString());
     }
     return result; 
   }
  */