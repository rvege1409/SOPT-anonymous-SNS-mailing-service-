var express = require('express'); 
var mysql = require('mysql'); 
var router =express.Router(); 
var connection = mysql.createConnection({
    'host' : 'aws-rds-mysql2.cdzli10abir2.us-west-2.rds.amazonaws.com', 
    'user' : 'user_id',
    'password' : 'user_password', 
    'database' : 'default_schema',
});

router.get('/', function(req, res, next) {  connection.query('select id, title, timestamp from board ' + 'order by timestamp desc;', function(error, cursor) {
res.json(cursor);
});
});

module.exports = router;